Thanks to Shane Glass and the repo here for the code to deploy the Colab Notebooks

- https://github.com/shanecglass/warehouse-jss-dev/blob/master/modules/data_warehouse/notebook_deployment.tf